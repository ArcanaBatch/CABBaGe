#!/usr/bin/perl -w

#################################################################################
#By:       Roberto Torres & Mauricio Flores                                     #                                                      #
#################################################################################
use strict;
use List::MoreUtils qw(uniq);
use FindBin;
use lib "$FindBin::Bin/../lib";
use Routines;
use List::Util qw(min max);
print
"
:'######:::::'###::::'########::'########:::::'###:::::'######:::'########:
'##... ##:::'## ##::: ##.... ##: ##.... ##:::'## ##:::'##... ##:: ##.....::
 ##:::..:::'##:. ##:: ##:::: ##: ##:::: ##::'##:. ##:: ##:::..::: ##:::::::
 ##:::::::'##:::. ##: ########:: ########::'##:::. ##: ##::'####: ######:::
 ##::::::: #########: ##.... ##: ##.... ##: #########: ##::: ##:: ##...::::
 ##::: ##: ##.... ##: ##:::: ##: ##:::: ##: ##.... ##: ##::: ##:: ##:::::::
. ######:: ##:::: ##: ########:: ########:: ##:::: ##:. ######::: ########:
:......:::..:::::..::........:::........:::..:::::..:::......::::........::  

CABBaGe: Classification Algorithm Based on a Bayesian method for Genomics
BC4: Naive Bayesian Classifier Module ver. 4.2\n
Copyright (C): Laboratorio de Biotecnologia y Bioinformatica Genomica
               ENCB-Instituto Politecnico Nacional\n
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation v.3.0\n\n
" 
;
 
my $MainPath = "$FindBin::Bin";

my ($Usage, $TrainingFile, $MetadataFile, $QryFile, $OutPath, $Stat, $PsCounts, $Max);

$Usage = "\nUSAGE\n  $FindBin::Script 
			<Training [File]>
                        <Metadata [File]>
                        <Query [File]>
                        <Output Path [Path]>\n\n";
unless(@ARGV) {
        print $Usage;
        exit;
}
chomp @ARGV;
$TrainingFile = $ARGV[0];
$MetadataFile = $ARGV[1];
$QryFile      = $ARGV[2];
$OutPath      = $ARGV[3];
$Stat         = 1;
$PsCounts     = 1;


my($LinesOnTrainingFile, $Line, $ColumnsOnTrainingFile, $N, $MetaData,
   $LinesOnMetaDataFile, $ColumnsOnMetaDataFile, $GlobalHits,
   $Region, $Element, $Class, $nClasses, $Classification,
   $Counter, $Hit, $Count, $Feature, $ElementHit, $ElementHits, $FeatureHit, $FeatureHits,
   $nFeature, $LinesOnQryFile, $ColumnsOnQryFile, $QryHit, $QryElement, $PossibleClass,
   $Probabilities, $Column, $pQryClass, $cpQryClass, $ReportFile);
my($i, $j);
my(@TrainingFile, @TrainingFileFields, @TrainingMatrix, @MetaDataField, @MetaDataFile,
   @MetaDataFileFields, @MetaDataMatrix, @Classes, @Elements, @QryFile, @QryFileFields,
   @QryMatrix);
my(%ClassOfElement, %TotalFeatureHits, %HitsOfFeaturesInClass, %pHitsOfFeaturesInClass,
   %cpHitsOfFeaturesInClass,
   %ElementClass, %Elements, %pClass, %cpClass, %ClassHits, %FeatureClass,
   %pFeatureClass, %cpFeatureClass, %FeatureTotalHits, %cpQry, %pQry);
my $TrainingMatrix = [ ];
my $QryMatrix = [ ];
my $Report = [ ];

$ReportFile = $OutPath ."/". "Prediction.csv";
$Classification = $OutPath ."/". "AsignedClass.txt";

if($Stat == 1){
        $Probabilities = $OutPath ."/". "Probabilities.csv";
}

#Loading the bolean training file
($LinesOnTrainingFile, $ColumnsOnTrainingFile, @TrainingMatrix) = Matrix($TrainingFile);
$nFeature = $LinesOnTrainingFile-1;
$N = $ColumnsOnTrainingFile-1;

#Loading the bolean query file
($LinesOnQryFile, $ColumnsOnQryFile, @QryMatrix) = Matrix($QryFile);

#Loading the metadata file
($LinesOnMetaDataFile, $ColumnsOnMetaDataFile, @MetaDataMatrix) = Matrix($MetadataFile);

# Obtaining classes
print "\nThe following columns were detected as possible classes:";
for ($i=1;$i<$ColumnsOnMetaDataFile;$i++){
        $PossibleClass = $MetaDataMatrix[0][$i];
        print "\n\t[$i] $PossibleClass";
}
print "\n\nPlease type the number of the desired class: ";
$Column = <STDIN>;
chomp $Column;

for ($i=1;$i<$LinesOnMetaDataFile;$i++){
	$Class = $MetaDataMatrix[$i]->[$Column];
	push @Classes, $Class;
}
@Classes = uniq(@Classes);
$nClasses = scalar@Classes;

for ($i=0;$i<$nClasses;$i++){
	for ($j=1;$j<$LinesOnMetaDataFile;$j++){
		$Element = $MetaDataMatrix[$j]->[0];
		$Class = $MetaDataMatrix[$j]->[1];
		$ClassOfElement{$Element} = $Class;
		if($Class eq $Classes[$i]){
                        $Elements{$Classes[$i]}++; #   <-------- Number of elements in each class
		}
	}
################################################################################
	$pClass{$Classes[$i]} = ($Elements{$Classes[$i]}/$N); # Probability of each class
	$cpClass{$Classes[$i]} = (1-$Elements{$Classes[$i]}/$N); # Complement probability of each class
}


#exit;




# Hits into the training matrix
$GlobalHits = 0;
for ($i=1; $i<$LinesOnTrainingFile; $i++){
	for ($j=1; $j<$ColumnsOnTrainingFile; $j++){
		$Hit = $TrainingMatrix[$i][$j];
		if ($Hit != 0){
			$GlobalHits++; #   <----------------------- Total of hits
		}
	}
}

#Hits of each class
foreach $Class(@Classes){
	for ($i=1;$i<$ColumnsOnTrainingFile; $i++){
		$Element = $TrainingMatrix[0][$i];
		if ($ClassOfElement{$Element} eq $Class){
			for ($j=1;$j<$LinesOnTrainingFile;$j++){
                                $ClassHits{$Class} += $TrainingMatrix[$j][$i]+$PsCounts;  # <- Total of hits in class
			}
		}
	}
}

#Hits of each feature in each class
foreach $Class(@Classes){
	for ($i=1;$i<$LinesOnTrainingFile;$i++){
		$Feature = $TrainingMatrix[$i][0];
                $TotalFeatureHits{$Feature} = 0;
		for ($j=1;$j<$ColumnsOnTrainingFile; $j++){
			$Element = $TrainingMatrix[0][$j];
                        $TotalFeatureHits{$Feature} += $TrainingMatrix[$i][$j]+$PsCounts; # <- Total Feature Hits
			if ($ClassOfElement{$Element} eq $Class){
				$HitsOfFeaturesInClass{$Feature}{$Class} += $TrainingMatrix[$i][$j]+$PsCounts; # <- Total Feature Hits in Class
			}
		}
	}
}

for ($i=1;$i<$LinesOnTrainingFile;$i++){
        $Feature = $TrainingMatrix[$i][0];
	foreach $Class(@Classes){
                $pHitsOfFeaturesInClass{$Feature}{$Class} = 1000*(($HitsOfFeaturesInClass{$Feature}{$Class}+1)/($ClassHits{$Class}+$nFeature));
                $cpHitsOfFeaturesInClass{$Feature}{$Class} = 1000*(($TotalFeatureHits{$Feature}-$HitsOfFeaturesInClass{$Feature}{$Class}+1)/(($GlobalHits-$ClassHits{$Class})+$nFeature));
	}
}

$Report -> [0][0] = "";

for ($i=1;$i<$ColumnsOnQryFile;$i++){
        $QryElement = $QryMatrix[0][$i];
        foreach $Class(@Classes){
                $pQryClass = $pClass{$Class};
                $cpQryClass = $cpClass{$Class};
                for ($j=1;$j<$LinesOnQryFile;$j++){
                        $Feature = $QryMatrix[$j][0];
                        $QryHit = $QryMatrix[$j][$i];
                        if($QryHit == 1){
                                #$pQryClass = ((($pQryClass)))*((($pHitsOfFeaturesInClass{$Feature}{$Class})));
                                #$cpQryClass = ((($cpQryClass)))*((($cpHitsOfFeaturesInClass{$Feature}{$Class})));
                                $pQryClass = $pQryClass*$pHitsOfFeaturesInClass{$Feature}{$Class};
                                $cpQryClass = $cpQryClass*$cpHitsOfFeaturesInClass{$Feature}{$Class};
                        }
                }
                $pQry{$Class}{$QryElement} = ($pQryClass);
                $cpQry{$Class}{$QryElement} = ($cpQryClass);
        }
}

open (PFILE, ">$Probabilities");

for($i=1; $i<$ColumnsOnQryFile; $i++){
   $QryElement = $QryMatrix[0][$i];

   for($j=0; $j<$nClasses; $j++){
      $Class = $Classes[$j];
      $Report -> [$i][0] = $QryElement;
      $Report -> [0][$j+1] = $Class;
      $Class = $Classes[$j];

      print PFILE "$QryElement,Class $Class,$pQry{$Class}{$QryElement}\n";
# 
   }
#
}
close PFILE;

print
"\n\nDONE...thank you for using CABBaGe\n\n";

exit;
