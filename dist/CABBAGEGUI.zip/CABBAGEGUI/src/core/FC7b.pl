#!/usr/bin/perl -w

#################################################################################
#By:       Roberto Torres & Mauricio Flores                                     #                                                      #
#################################################################################
use strict;
use List::Util qw(max min);
use List::MoreUtils qw(any uniq first_index);
use FindBin;
use lib "$FindBin::Bin/../lib";
use Routines;

print
"
:'######:::::'###::::'########::'########:::::'###:::::'######:::'########:
'##... ##:::'## ##::: ##.... ##: ##.... ##:::'## ##:::'##... ##:: ##.....::
 ##:::..:::'##:. ##:: ##:::: ##: ##:::: ##::'##:. ##:: ##:::..::: ##:::::::
 ##:::::::'##:::. ##: ########:: ########::'##:::. ##: ##::'####: ######:::
 ##::::::: #########: ##.... ##: ##.... ##: #########: ##::: ##:: ##...::::
 ##::: ##: ##.... ##: ##:::: ##: ##:::: ##: ##.... ##: ##::: ##:: ##:::::::
. ######:: ##:::: ##: ########:: ########:: ##:::: ##:. ######::: ########:
:......:::..:::::..::........:::........:::..:::::..:::......::::........::  

CABBaGe: Classification Algorithm Based on a Bayesian method for Genomics
FC7: Feature Extractor Module ver. 7.01\n
Copyright (C): Laboratorio de Biotecnologia y Bioinformatica Genomica
               ENCB-Instituto Politecnico Nacional\n
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation v.3.0\n\n
" 
;

my $MainPath = "$FindBin::Bin";

my ($Usage, $TrainingFile, $MetadataFile, $OutPath, $Method, $X2, $IG, $OR,
    $PsCounts, $MI, $DotPlot, $HeatMapPlot, $Correlation, $Sort, $Clusters,
    $Dendrogram, $Runs, $Threshold);

$Usage = "\nUSAGE\n  $FindBin::Script                    
			<TrainningFile [File]>
                        <MetadataFile [File]>
                        <Output Path [Path]>
                        <Statistic Test [X2, IG, OR, LO, MI]>\n\n";
unless(@ARGV) {
        print $Usage;
        exit;
}
chomp @ARGV;
$TrainingFile   = $ARGV[0];
$MetadataFile   = $ARGV[1];
$OutPath        = $ARGV[2];
$PsCounts       = 0;
$Method         = $ARGV[3];  # <- X2, IG, OR, LO, MI

$Runs           = 1;

my($Test, $Run, $TestReport, $PercentagesReport, $Plot, $HeatMap, $PlotRScript,
   $LinesOnTrainingFile, $nFeature, $Line, $ColumnsOnTrainingFile, $N,
   $LinesOnMetaDataFile, $ColumnsOnMetaDataFile, $PossibleClass, $Column, $Class,
   $nClasses, $Element, $GlobalHits, $Hit, $Feature, $iClass, $a, $b, $c, $d,
   $nConfusion, $ChiConfidence, $Round, $HeatMapRScript, $Matrix, $CombinedInformative,
   $TestInformative, $PresenceInformative, $InformativeFeatures, $InformativeLines,
   $CombinedReport, $TestReportLine, $CombinedReportLine, $BoleanInformative,
   $TrainingHeader, $PresenceReportLine, $SummaryReport, $InformativeIndex,
   $InformativeClass, $SuperHeatMapRScript);
my($i, $j);
my(@TrainingFile, @TrainingFileFields, @TrainingMatrix, @MetaDataFile,
   @MetaDataFileFields, @MetaDataMatrix, @Classes, @Elements, @ChiConfidence,
   @ChiConfidences, @TestReport, @Combined, @TestReportData, @Presence,
   @PresenceData);
my(%ClassOfElement, %Elements, %pClass, %cpClass, %ClassHits,
   %HitsOfFeaturesInClass, %TotalFeatureHits, %Test,%PercentageOfFeatureInClass);
my(%a, %b, %c, %d);


if ($Method eq "IG"){
   $Test = "Information_Gain";
}elsif ($Method eq "X2"){
   $Test = "Chi_Square";
}elsif ($Method eq "OR"){
   $Test = "Odds_Ratio";
}elsif ($Method eq "MI"){
   $Test = "Mutual_Information";
}elsif ($Method eq "LO"){
   $Test = "LogOdds";
}else {
   print "\nYou should select only one test option (--X2, --MLE or --OR)\n\tProgram finished!\n\n";
   exit;
}

# Loading the metadata file
($LinesOnMetaDataFile, $ColumnsOnMetaDataFile, @MetaDataMatrix) = Matrix($MetadataFile);

# Obtaining classes
print "\nThe following columns were detected as possible classes:";
for ($i=1;$i<$ColumnsOnMetaDataFile;$i++){
        $PossibleClass = $MetaDataMatrix[0][$i];
        print "\n\t[$i] $PossibleClass";
}
print "\n\nPlease type the index of the desired class: ";
$Column = <STDIN>;
chomp $Column;

for ($i=1;$i<$LinesOnMetaDataFile;$i++){
	$Class = $MetaDataMatrix[$i]->[$Column];
	push @Classes, $Class;
}
@Classes = uniq(@Classes);
$nClasses = scalar@Classes;

foreach $Run (1 .. $Runs){
        
my $Report = [ ];
my $Percentages = [ ];
my $Combined = [ ];
        
        $TestReport          = $OutPath ."/". $Test . "_Values_Run" . $Run . ".csv";
        $PercentagesReport   = $OutPath ."/". "PresencePercentages_Run" . $Run . ".csv";
        
              
        # Loading the bolean training file
        ($LinesOnTrainingFile, $ColumnsOnTrainingFile, @TrainingMatrix) = Matrix($TrainingFile);
        $nFeature = $LinesOnTrainingFile-1;
        $N = $ColumnsOnTrainingFile-1;
        
        #$TrainingHeader = join ',', @{$TrainingMatrix[0]} [0..$ColumnsOnTrainingFile];
        $TrainingHeader = join ',', @{$TrainingMatrix[0]} [0..$N];
        chop $TrainingHeader;
        #chop $TrainingHeader;
        
        
        for ($i=0;$i<$nClasses;$i++){
                #for ($j=1;$j<$LinesOnMetaDataFile;$j++){
                for ($j=1;$j<$ColumnsOnTrainingFile;$j++){
                        $Element = $TrainingMatrix[0]->[$j];
                        $Class = $MetaDataMatrix[$j]->[$Column];
                        $ClassOfElement{$Element} = $Class;
                        
                        if($Class eq $Classes[$i]){
                                $Elements{$Classes[$i]}++; #   <-------- Number of elements in each class
                        }
                }
        }

        # Hits into the training matrix
        $GlobalHits = 0;
        for ($i=1; $i<$LinesOnTrainingFile; $i++){
                for ($j=1; $j<$ColumnsOnTrainingFile; $j++){
                        $Hit = $TrainingMatrix[$i][$j];
                        if ($Hit != 0){
                                $GlobalHits++; #   <----------------------- Total of hits
                        }
                }
        }

        #Hits of each class
        foreach $Class(@Classes){
                for ($i=1;$i<$ColumnsOnTrainingFile; $i++){
                        $Element = "$TrainingMatrix[0][$i]";
                        if ($ClassOfElement{$Element} eq $Class){
                                for ($j=1;$j<$LinesOnTrainingFile;$j++){
                                        $ClassHits{$Class} += $TrainingMatrix[$j][$i]+$PsCounts;  # <- Total of hits in class
                                }
                        }
                }
        }

        #Hits of each feature in each class
        foreach $Class(@Classes){
                for ($i=1;$i<$LinesOnTrainingFile;$i++){
                        $Feature = $TrainingMatrix[$i][0];
                        $TotalFeatureHits{$Feature} = 0;
                        for ($j=1;$j<$ColumnsOnTrainingFile; $j++){         
                                $Element = $TrainingMatrix[0][$j];
                                $TotalFeatureHits{$Feature} += $TrainingMatrix[$i][$j]+$PsCounts; # <- Total Feature Hits
                                if ($ClassOfElement{$Element} eq $Class){
                                        $HitsOfFeaturesInClass{$Feature}{$Class} += $TrainingMatrix[$i][$j]+$PsCounts; # <- Total Feature Hits in Class
                                }
                        }
                        $PercentageOfFeatureInClass{$Feature}{$Class} = ($HitsOfFeaturesInClass{$Feature}{$Class})/(($Elements{$Class})+0.1)*100; # <- Percentage of Feature Hits in Class
                }
        }

        # Statistic tests
        $Report -> [0][0] = "Feature";
        $Percentages -> [0][0] = "Feature";
        $iClass = 1;
        $InformativeLines = 0; 
        for ($i=0; $i<$nClasses; $i++){
           $Class = $Classes[$i];
           $Report -> [0][$i+1] = $Class;
           $Percentages -> [0][$i+1] = $Class;
           for ($j=1;$j<$LinesOnTrainingFile;$j++){
              $Feature = $TrainingMatrix[$j][0];
        
              $a= (($HitsOfFeaturesInClass{$Feature}{$Class}))+0.001; # hits de sonda a en clase a
              $b= (($TotalFeatureHits{$Feature}-$HitsOfFeaturesInClass{$Feature}{$Class}))+0.001; # Hits de sonda a que no están en clase A
              $c= (($Elements{$Class}-$HitsOfFeaturesInClass{$Feature}{$Class}))+0.001; # Numero de mismaches en clase A (numero de ceros en clase A)
              $d= ((($N-$Elements{$Class})-($TotalFeatureHits{$Feature}-$HitsOfFeaturesInClass{$Feature}{$Class})))+0.001; # Numero de ceros fuera de A
              $nConfusion = $a+$b+$c+$d;
                    
              if ($Method eq "IG"){         # <------------------ Maximum Likelihood Estimation -- Information Gain
                 $Test{$Feature} = ((-1*(($a+$c)/$nConfusion))*log10(($a+$c)/$nConfusion))+
                                   (($a/$nConfusion)*log10($a/($a+$b)))+
                                   (($c/$nConfusion)*log10($c/($c+$d)));
              }elsif ($Method eq "X2"){     # <------------------------------------ Chi square
                $Test{$Feature} = (($nConfusion*(($a*$d)-($b*$c))**2))/(($a+$c)*($a+$b)*($b+$d)*($c+$d));
              }elsif ($Method eq "OR"){     # <------------------------------------ Odds Ratios
                $Test{$Feature} = ($a*$d)/($b*$c);
              }elsif ($Method eq "LO"){     # <------------------------------------ LogOdds
                $Test{$Feature} = log2(($a*$d)/($b*$c));
              }elsif ($Method eq "MI"){     # <------------------------------------ Mutual information
                $Test{$Feature} = log10(($a*$nConfusion)/(($a+$b)*($a+$c)));
              }
              
              $Report -> [$j][0] = $Feature;
              $Report -> [$j][$iClass] = $Test{$Feature};
              
              $Percentages -> [$j][0] = $Feature;
              $Percentages -> [$j][$iClass] = $PercentageOfFeatureInClass{$Feature}{$Class};
           }
           $iClass++;
        }
        
        ## Building output file
        open (FILE, ">$TestReport");
        open (PERCENTAGES, ">$PercentagesReport");
        for ($i=0;$i<$LinesOnTrainingFile;$i++){
           for ($j=0;$j<$nClasses+1;$j++){
                if($j < $nClasses){
                        print FILE $Report -> [$i][$j], ",";
                        print PERCENTAGES $Percentages -> [$i][$j], ",";
                }elsif($j == $nClasses){
                        print FILE $Report -> [$i][$j];
                        print PERCENTAGES $Percentages -> [$i][$j];
                }
           }
           print FILE "\n";
           print PERCENTAGES "\n";
        }
        close FILE;
        close PERCENTAGES;
        
                }

print
   "\n\nDONE...thank you for using CABBaGe\n\n";
                             
    
exit;