#!/usr/bin/python3


# :'######:::::'###::::'########::'########:::::'###:::::'######:::'########:
# '##... ##:::'## ##::: ##.... ##: ##.... ##:::'## ##:::'##... ##:: ##.....::
#  ##:::..:::'##:. ##:: ##:::: ##: ##:::: ##::'##:. ##:: ##:::..::: ##:::::::
#  ##:::::::'##:::. ##: ########:: ########::'##:::. ##: ##::'####: ######:::
#  ##::::::: #########: ##.... ##: ##.... ##: #########: ##::: ##:: ##...::::
#  ##::: ##: ##.... ##: ##:::: ##: ##:::: ##: ##.... ##: ##::: ##:: ##:::::::
# . ######:: ##:::: ##: ########:: ########:: ##:::: ##:. ######::: ########:
# :......:::..:::::..::........:::........:::..:::::..:::......::::........::

# CABBaGe: Classification Algorithm Based on a Bayesian method for Genomics
# Copyright (C): Laboratorio de Biotecnologia y Bioinformatica Genomica
#               ENCB-Instituto Politecnico Nacional\n
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation v.3.0\n\n

# GUI developed by: Mauricio Flores-Valdez   mfv@live.com.mx
# -----------------------------------------------------------------------


# --MODULES--------------------------------------------------------------
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from PIL import ImageTk, Image
from tkinter.filedialog import askopenfilename
import webbrowser
import pandas as pd
import tkinter as tk
import subprocess
import shutil
import os
###################################
from ttkthemes import ThemedTk
###################################
# --MODULES--------------------------------------------------------------

# --VARIABLES-----------------------------------------------------------
TRAINING = "0"
METADATA = "0"
QUERY = "0"
OUTFILEBC = "0"
TRAINING2 = "0"
METADATA2 = "0"
TEST = "0"
input1bis = "0"
input2bis = "0"
input3bis = "0"
input4bis = "0"
input5bis = "0"
input6bis = "0"
#######################
NoFeatures = 0
Output = "out"
Input = "ChiFake2.csv"
# --VARIABLES------------------------------------------------------------

# --FUNCTIONS------------------------------------------------------------


def clear():
    input_entry1.delete(0, END)
    input_entry2.delete(0, END)
    input_entry3.delete(0, END)
    input_entry4.delete(0, END)
    input_entry5.delete(0, END)
    #####################################
    input_entry6.delete(0, END)
    #####################################

    combo1a.current(0)

    #####################################
    outfileEntry1.delete(0, END)
    outfileEntry2.delete(0, END)
    #####################################
# Clear input fileds


def BC4():
    commandlineBC4[2] = input1bis
    commandlineBC4[3] = input2bis
    commandlineBC4[4] = input3bis
    if input1bis == "0" or input2bis == "0" or input3bis == "0":
        print("Please fill all fields")
        messagebox.showwarning("Warning", "Please fill all the fields")
        exit
    else:
        print(commandlineBC4)
        os.mkdir("ResultsBC")
        subprocess.run(commandlineBC4, shell=True)
        messagebox.showinfo(
            message="Process Complete,\nprobabilities are found in the " +
            "ResultsBC directory")

        dfClass = pd.read_csv(".\ResultsBC\Probabilities.csv", names=[
                              "Sample", "Class", "Probability"])

        Prediction = dfClass.sort_values('Probability').drop_duplicates(
            ['Sample'], keep='last')

        Prediction.to_csv('Prediction.csv', mode='a', index=None)
        shutil.move('Prediction.csv', "ResultsBC")

# BC4 command


def FC7():
    commandlineFC7[2] = input4bis
    commandlineFC7[3] = input5bis
    if input4bis == "0" or input5bis == "0":
        print("Please fill all fields")
        messagebox.showwarning("Warning", "Please fill all the fields")
        exit
    else:
        FC7combo = combo1a.get()
        commandlineFC7[5] = FC7combo
        print(commandlineFC7)
        os.mkdir("ResultsFE")
        subprocess.run(commandlineFC7)
        messagebox.showinfo(
            message="Process Complete,\nprobabilities are found in the " +
            "ResultsFE directory")
# FC7 command


def FF2():
    global Nofeatures
    global Output
    global Input
    NoFeatures = outfileEntry2.get()
    Output = outfileEntry1.get()
    Input = input6bis
    if input6bis == "0" or Output == "0" or int(NoFeatures) == 0:
        print("Please fill all fields")
        messagebox.showwarning("Warning", "Please fill all the fields")
        exit
    else:
        df = pd.read_csv(Input, names=None)
        # index = df.index
        print(df.info())
        rows = len(df)
        if (rows-1) <= int(NoFeatures):
            print("Too much")
            messagebox.showwarning("Warning", "No Of Features cannot exceed: "
                                   + str(rows-1))
            exit
        else:
            E = df.columns[1:]
        # get top n features
            for column in E:
                df.nlargest(int(NoFeatures),
                            column, keep="all").to_csv('top.csv', mode='a',
                                                       index=False)
        # temp file
            df2 = pd.read_csv("top.csv", header=None)
        # generate output
            os.mkdir("ResultsFF")
            df3 = df2.drop_duplicates(
                subset=[0], keep='first', inplace=False)
            df4 = df3.head(int(NoFeatures)+1).to_csv(".\ResultsFF\ " + Output +
                                                 str(NoFeatures) + '.csv',
                                                 index=False)
            os.remove("top.csv")
            messagebox.showinfo(
                message="Process Complete,\nprobabilities are found in the " +
                "ResultsFF directory")

    FeatureFile = (".\ResultsFF\ " + Output + str(NoFeatures) + '.csv')
    fh = open(FeatureFile)
    lst = list()
    for line in fh:
        if line.startswith(("A", "C", "G", "T")):
            line = line.rstrip()
            words = line.split(",")
            lst.append(words[0])

    with open('FilteredVPS.txt', 'w') as f:
        for item in lst:
            f.write("%s\n" % item)
    f.close()
    shutil.move('FilteredVPS.txt', 'ResultsFF')


# FF2 command


def input1():
    global input1bis
    input_path_1 = tk.filedialog.askopenfilename()
    input_entry1.delete(0, END)  # Remove current text in entry
    input_entry1.insert(0, input_path_1)  # Insert the 'path'
    input1bis = str(input_path_1)
# Input path load1


def input2():
    global input2bis
    input_path_2 = tk.filedialog.askopenfilename()
    input_entry2.delete(0, END)  # Remove current text in entry
    input_entry2.insert(0, input_path_2)  # Insert the 'path'
    input2bis = str(input_path_2)
# Input path load2


def input3():
    global input3bis
    input_path_3 = tk.filedialog.askopenfilename()
    input_entry3.delete(0, END)  # Remove current text in entry
    input_entry3.insert(0, input_path_3)  # Insert the 'path'
    input3bis = str(input_path_3)
# Input path load3


def input4():
    global input4bis
    input_path_4 = tk.filedialog.askopenfilename()
    input_entry4.delete(0, END)  # Remove current text in entry
    input_entry4.insert(0, input_path_4)  # Insert the 'path'
    input4bis = str(input_path_4)
# Input path load4


def input5():
    global input5bis
    input_path_5 = tk.filedialog.askopenfilename()
    input_entry5.delete(0, END)  # Remove current text in entry
    input_entry5.insert(0, input_path_5)  # Insert the 'path'
    input5bis = str(input_path_5)
# Input path load5
#####################################################


def input6():
    global input6bis
    input_path_6 = tk.filedialog.askopenfilename()
    input_entry6.delete(0, END)  # Remove current text in entry
    input_entry6.insert(0, input_path_6)  # Insert the 'path'
    input6bis = str(input_path_6)
# Input path load6
########################################################


def callback(url):
    webbrowser.open_new(url)
# Browser call

# --FUNCTIONS------------------------------------------------------------


# --GUI------------------------------------------------------------------
########################################
root = ThemedTk(theme="equilux")
########################################
# root = Tk()

root.resizable(0, 0)
# Master window Intitialize

root.wm_iconbitmap('.\Dist\cabbage3.ico')      # Mini icon in window frame
root.wm_title('CABBaGe: Classification Algorithm Based on a Bayesian' +
              ' method for Genomics')  # Master window title

notebook = ttk.Notebook(root)
notebook.grid(row=0, column=0)
tab1 = ttk.Frame(notebook)
tab2 = ttk.Frame(notebook)
tab3 = ttk.Frame(notebook)
notebook.add(tab1, text='BayesianClassifier')
notebook.add(tab2, text='FeatureExtractor')
notebook.add(tab3, text='FeatureFilter')
# Creates tabs inside Master window

link1 = Label(root, text='GitHub CABBaGe',
              font=("Helvetica", 8, "underline"), fg="CadetBlue1",
              cursor="hand2", bg="#464646")
link1.grid(row=0, column=0, sticky=NE)
link1.bind("<Button-1>", lambda e:
           callback('https://github.com/ArcanaBatch/CABBaGe'))
# URL

img1 = ImageTk.PhotoImage(Image.open(r'.\Dist\imagen3.png'))
panel1 = Label(tab1, image=img1, bg="#464646")
panel1.grid(row=1, column=0, rowspan=4)

img2 = ImageTk.PhotoImage(Image.open(r'.\Dist\imagen3.png'))
panel2 = Label(tab2, image=img2, bg="#464646")
panel2.grid(row=1, column=0, rowspan=4)

img3 = ImageTk.PhotoImage(Image.open(r'.\Dist\imagen3.png'))
panel3 = Label(tab3, image=img3, bg="#464646")
panel3.grid(row=1, column=0, rowspan=4)

# Vamp images

VampText1 = Label(tab1, text='BC4: Naive Bayes Classifier Module \nver 4.0',
                  bg="#464646", fg="CadetBlue1")
VampText1.grid(row=1, column=1, rowspan=4)

VampText2 = Label(tab2, text='FC7: Feature Extractor Module \nver 7.0',
                  bg="#464646", fg="CadetBlue1")
VampText2.grid(row=1, column=1, rowspan=4)

VampText3 = Label(tab3, text='FF2: Feature Filter Module \nver 3.0',
                  bg="#464646", fg="CadetBlue1")
VampText3.grid(row=1, column=1, rowspan=4)
# Vamp texts

# --BC4 WIDGETS----------------------------------------------------------

input_path1 = Label(tab1, text='Training File:', bg="#464646", fg="gray80")
input_entry1 = Entry(tab1, text="", width=50, bg="#e6ffff")
browse1 = Button(tab1, text='Browse', command=input1, bg="#464646",
                 fg="gray80")
input_path1.grid(row=5, column=0, sticky=W)
input_entry1.grid(row=5, column=1, sticky=W)
browse1.grid(row=5, column=2, sticky=W)

input_path2 = Label(tab1, text='Meta Data File:', bg="#464646", fg="gray80")
input_entry2 = Entry(tab1, text="", width=50, bg="#e6ffff")
browse2 = Button(tab1, text='Browse', command=input2, bg="#464646",
                 fg="gray80")
input_path2.grid(row=6, column=0, sticky=W)
input_entry2.grid(row=6, column=1, sticky=W)
browse2.grid(row=6, column=2, sticky=W)

input_path3 = Label(tab1, text='Query File:', bg="#464646", fg="gray80")
input_entry3 = Entry(tab1, text="", width=50, bg="#e6ffff")
browse3 = Button(tab1, text='Browse', command=input3, bg="#464646",
                 fg="gray80")
input_path3.grid(row=7, column=0, sticky=W)
input_entry3.grid(row=7, column=1, sticky=W)
browse3.grid(row=7, column=2, sticky=W)

begin_button1 = Button(tab1, text='Start', command=BC4, width=10, bg="#464646",
                       fg="gray80")
begin_button1.grid(row=9, column=1, sticky=W)

PlaceHolder1 = Label(tab1, text="   ", bg="#464646", fg="gray80")
PlaceHolder1.grid(row=8, column=1)

clear1 = Button(tab1, text='Clear', command=clear, width=10, bg="#464646",
                fg="gray80")
clear1.grid(row=9, column=1, sticky=E)


# --FC7 WIDGETS---------------------------------------------------------

input_path4 = Label(tab2, text='Training File:', bg="#464646", fg="gray80")
input_entry4 = Entry(tab2, text="", width=50, bg="#e6ffff")
browse4 = Button(tab2, text='Browse', command=input4, bg="#464646",
                 fg="gray80")
input_path4.grid(row=5, column=0, sticky=W)
input_entry4.grid(row=5, column=1, sticky=W)
browse4.grid(row=5, column=2, sticky=W)

input_path5 = Label(tab2, text='Meta Data File:', bg="#464646", fg="gray80")
input_entry5 = Entry(tab2, text="", width=50, bg="#e6ffff")
browse5 = Button(tab2, text='Browse', command=input5, bg="#464646",
                 fg="gray80")
input_path5.grid(row=6, column=0, sticky=W)
input_entry5.grid(row=6, column=1, sticky=W)
browse5.grid(row=6, column=2, sticky=W)

label1a = Label(tab2, text='Test:', bg="#464646", fg="gray80")
label1a.grid(row=7, column=0, sticky=W)
combo1a = ttk.Combobox(tab2, width=3)
combo1a.grid(row=7, column=1, sticky=W)
combo1a['values'] = ('X2', 'IG', 'OR', 'LO', 'MI')
combo1a.current(0)


begin_button2 = Button(tab2, text='Start', command=FC7, width=10, bg="#464646",
                       fg="gray80")
begin_button2.grid(row=9, column=1, sticky=W)
# Start button VFAT

clear1 = Button(tab2, text='Clear', command=clear, width=10, bg="#464646",
                fg="gray80")
clear1.grid(row=9, column=1, sticky=E)
# Clear button VFAT

PlaceHolder1 = Label(tab2, text="   ", bg="#464646")
PlaceHolder1.grid(row=8, column=1)

# --FF2 WIDGETS ---------------------------------------------------------

input_path6 = Label(tab3, text='Probabilities File:', bg="#464646",
                    fg="gray80")
input_entry6 = Entry(tab3, text="", width=50, bg="#e6ffff")
browse6 = Button(tab3, text='Browse', command=input6, bg="#464646",
                 fg="gray80")
input_path6.grid(row=5, column=0, sticky=W)
input_entry6.grid(row=5, column=1, sticky=W)
browse6.grid(row=5, column=2, sticky=W)

outfile1 = Label(tab3, text='Out File Name:', bg="#464646", fg="gray80")
outfile1.grid(row=6, column=0, sticky=W)
outfileEntry1 = Entry(tab3, width=50, bg="#e6ffff")
outfileEntry1.grid(row=6, column=1, sticky=W)

outfile2 = Label(tab3, text='No. Of Features:', bg="#464646", fg="gray80")
outfile2.grid(row=7, column=0, sticky=W)
outfileEntry2 = Entry(tab3, width=10, bg="#e6ffff")
outfileEntry2.grid(row=7, column=1, sticky=W)


begin_button3 = Button(tab3, text='Start', command=FF2, width=10, bg="#464646",
                       fg="gray80")
begin_button3.grid(row=9, column=1, sticky=W)

clear3 = Button(tab3, text='Clear', command=clear, width=10, bg="#464646",
                fg="gray80")
clear3.grid(row=9, column=1, sticky=E)

PlaceHolder3 = Label(tab3, text="   ", bg="#464646")
PlaceHolder3.grid(row=8, column=1)

# --BC4 logic------------------------------------------------------------
commandlineBC4 = ["perl", ".\src\core\BC4c.pl", TRAINING, METADATA, QUERY,
                  ".\ResultsBC"]
# --FC7 logic------------------------------------------------------------
commandlineFC7 = ["perl", ".\src\core\FC7c.pl", TRAINING2, METADATA2,
                  ".\ResultsFE", TEST]
# --FF2 logic------------------------------------------------------------


root.mainloop()
# --GUI------------------------------------------------------------------
